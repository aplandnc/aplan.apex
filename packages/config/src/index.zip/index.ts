// packages/config/src/index.ts
// Pages Router 전용 (admin 앱용)

export { supabase, getSupabaseBrowserClient } from "./supabaseClient";
export { createSupabaseServerClient } from "./supabaseServer";

// App Router 클라이언트 (staff/desk/info 앱용)
export { supabaseAppClient } from "./supabaseAppClient";

// 간단한 이름으로 alias (Pages Router용)
export { supabase as supabaseClient } from "./supabaseClient";
export { createSupabaseServerClient as supabaseServer } from "./supabaseServer";

// ❌ supabaseAppServer는 여기서 export 안함!
// → App Router 앱에서는 "@apex/config/app"에서 import

// packages/config/src/supabaseServer.ts
import { createPagesServerClient } from "@supabase/auth-helpers-nextjs";

/**
 * ✅ Pages Router(admin) 전용 서버 클라이언트
 * 사용처:
 * - getServerSideProps(ctx)
 * - pages/api(req, res)
 *
 * ❌ App Router에서는 절대 사용 금지
 */

export function supabaseServer(ctx: any) {
  return createPagesServerClient(ctx);
}

// 별칭 (기존 코드 호환용)
export const createSupabaseServerClient = supabaseServer;
export const createSupabasePagesServerClient = supabaseServer;

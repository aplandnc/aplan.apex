// packages/config/src/index-app.ts
// App Router 전용 (staff/desk/info 앱용)

export { supabaseAppClient } from "./supabaseAppClient";


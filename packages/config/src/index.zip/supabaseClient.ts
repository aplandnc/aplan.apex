// packages/config/src/supabaseClient.ts
import { createPagesBrowserClient } from "@supabase/auth-helpers-nextjs";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!url || !anonKey) {
  throw new Error("Missing env");
}

let _pagesBrowserClient: ReturnType<typeof createPagesBrowserClient> | null = null;

export function getSupabaseBrowserClient() {
  if (typeof window === "undefined") {
    throw new Error("브라우저 전용");
  }
  if (!_pagesBrowserClient) {
    _pagesBrowserClient = createPagesBrowserClient();
  }
  return _pagesBrowserClient;
}

export const supabaseClient = typeof window !== "undefined" 
  ? getSupabaseBrowserClient()
  : new Proxy({} as any, {
      get() {
        throw new Error("브라우저 전용");
      }
    });

export const supabase = supabaseClient;
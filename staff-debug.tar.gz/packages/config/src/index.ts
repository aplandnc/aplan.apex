// packages/config/src/index.ts
// ✅ App Router 통일 엔트리 (admin/staff/desk/info 공통)

export { supabaseAppClient } from "./supabaseAppClient";

